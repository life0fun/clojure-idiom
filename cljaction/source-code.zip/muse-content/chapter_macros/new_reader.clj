(ns chapter-macros.new-reader)

(defn new-read-string [string]
  )